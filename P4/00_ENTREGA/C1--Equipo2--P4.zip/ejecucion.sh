#!/bin/bash

#  Fichero:  ejecucion.sh
#  Autores:  Joaquín García Venegas
#            Joaquín Alejandro España Sánchez
#            Pedro Bedmar López
#            Alejandro Escalona García
#  Fecha: 18/05/20

mkdir graficos datos;
make

#---ALGORITMO DE CERCANIA---
./cercania tsp_escenarios_ejecucion/ulysses16.tsp > datos/salida-cercania-ulysses16.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/cercania-ulysses16.png';
plot 'datos/salida-cercania-ulysses16.txt' using 2:3 w lp lc 'red' lw 2 title 'cercania'; 
"

./cercania tsp_escenarios_ejecucion/burma14.tsp > datos/salida-cercania-burman14.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/cercania-burman14.png';
plot 'datos/salida-cercania-burman14.txt' using 2:3 w lp lc 'red' lw 2 title 'cercania';
"


#---ALGORITMO PROPIO-------
./propio tsp_escenarios_ejecucion/ulysses16.tsp > datos/salida-propio-ulysses16.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/propio-ulysses16.png';
plot 'datos/salida-propio-ulysses16.txt' using 2:3 w lp lc 'olive' lw 2 title 'propio'; 
"

./propio tsp_escenarios_ejecucion/burma14.tsp > datos/salida-propio-burman14.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/propio-burman14.png';
plot 'datos/salida-propio-burman14.txt' using 2:3 w lp lc 'olive' lw 2 title 'propio';
"

#----ALGORITMO DE INSERCION---
./insercion tsp_escenarios_ejecucion/ulysses16.tsp > datos/salida-insercion-ulysses16.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/insercion-ulysses16.png';
plot 'datos/salida-insercion-ulysses16.txt' using 2:3 w lp lc 'blue' lw 2 title 'insercion'; 
"

./insercion tsp_escenarios_ejecucion/burma14.tsp > datos/salida-insercion-burman14.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/insercion-burman14.png';
plot 'datos/salida-insercion-burman14.txt' using 2:3 w lp lc 'blue' lw 2 title 'insercion';
"

#----ALGORITMO DE PROGRAMACIÓN DINÁMICA---
./tsp-PD tsp_escenarios_ejecucion/ulysses16.tsp > datos/salida-tsp-PD-ulysses16.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/tsp-PD-ulysses16.png';
plot 'datos/salida-tsp-PD-ulysses16.txt' using 2:3 w lp lc 'chartreuse' lw 2 title 'tsp-PD'; 
"

./tsp-PD tsp_escenarios_ejecucion/burma14.tsp > datos/salida-tsp-PD-burman14.txt
gnuplot -e "
set terminal png size 1024, 768;
set size ratio -1;
set output 'graficos/tsp-PD-burman14.png';
plot 'datos/salida-tsp-PD-burman14.txt' using 2:3 w lp lc 'chartreuse' lw 2 title 'tsp-PD';
"

