/* 
    Fichero: genera-unimodal.cpp
    Autores:    Joaquín García Venegas
                Joaquín Alejandro España Sánchez
                Pedro Bedmar López
                Alejandro Escalona García
    Fecha: 05/04/20
    Compilación: g++ genera-unimodalDyV.cpp -o genera-unimodalDyV
*/
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <climits>
#include <cassert>
#include <chrono>

using namespace std;
// generador de ejemplos para el problema de la serie unimodal
// de números. Se genera un índice aleatorio entre 1 y n-2, se
// asigna el mayor entero (n-1) a ese índice, a los índices
// anteriores a p se le asignan valores en orden creciente (0,1,...,p-1)
// y a los índices mayores que p se le asignan valores en orden
// decreciente (n-2, n-1,...,p)

double uniforme() //Genera un n�mero uniformemente distribuido en el
                  //intervalo [0,1) a partir de uno de los generadores
                  //disponibles en C.
{
    double u;
    u = (double)rand();
    u = u / (double)(RAND_MAX + 1.0);
    return u;
}

// Función realizada aplicando la técnica DyV
int UnimodalDyV(int T[], int inicio, int final)
{
    int tamanio = final - inicio + 1;

    //Caso base cuando quedan 2 elementos
    if(tamanio <= 2){
        //Devolvemos -1 porque el indice no puede ser ni el primero
        //ni el ultimo del vector como dice el enunciado
        return -1;
    }
    // Si el vector tiene más de 2 elementos aplicaremos el metodo DyV
    else{ 
        int ind_centro =  inicio + ((final-inicio)/2);
        int valor_centro = T[ind_centro]; //Elemento del centro del vector
        int ele_izda_centro = T[ind_centro-1]; //Elemento a la izda del centro
        int ele_dcha_centro = T[ind_centro+1]; //Elemento a la dcha del centro

        //Si el valor del centro es mayor que el elemento a su izquierda y el de la derecha
        //entonces sera el indice p, ya que a la izda tiene los numeros ascendientes
        //menores que el (el indice p es el utlimo ascendente) y a la dcha los descendientes
        if(valor_centro > ele_izda_centro && valor_centro > ele_dcha_centro)
            return ind_centro;
        
        //Si el valor del centro es menor que el elemento a su izquierda, se coge
        //la parte del vector que queda a la izquierda del centro (incluido)
        else if(valor_centro < ele_izda_centro)
            return UnimodalDyV(T, inicio, ind_centro );
        
        // Si el valor del centro es mayor que el elemento a su izquierda se coge
        // la parte del vector que queda a la derecha del centro
        else if(valor_centro > ele_izda_centro)
            return UnimodalDyV(T, ind_centro, final);     
    }
}

int main(int argc, char *argv[])
{
    
    if (argc != 2)
    {
        cerr << "Formato " << argv[0] << " <num_elem>" << endl;
        return -1;
    }
    clock_t tantes;    // Valor del reloj antes de la ejecución
    clock_t tdespues;  // Valor del reloj después de la ejecución

    int n = atoi(argv[1]);

    int *T = new int[n];
    assert(T);

    srand(time(0));
    double u = uniforme();
    int p = 1 + (int)((n - 2) * u);
    T[p] = n - 1;

    // Rellenar parte izquierda ascendentemente
    for (int i = 0; i < p; i++)
        T[i] = i;

    // Rellenar parte derecha descendentemente
    for (int i = p + 1; i < n; i++)
        T[i] = n - 1 - i + p;

    //auto antes = std::chrono::high_resolution_clock::now();       // Guardar tiempo de inicio
    int indice_p = UnimodalDyV(T, 0, n-1);
    //auto despues = std::chrono::high_resolution_clock::now();     // Guargar tiempo de fin

    // Calcular tiempo del algoritmo
    //std::chrono::duration<double> duracion = despues - antes;

    // Imprimir vector
    for (int j = 0; j < n; j++)
        cout << T[j] << " ";
    
    // Imprimir valor del indice p
    cout << "\nEl valor del indice p es: " << indice_p << endl;
    //cout << n << "  " << duracion.count() << endl;
}
