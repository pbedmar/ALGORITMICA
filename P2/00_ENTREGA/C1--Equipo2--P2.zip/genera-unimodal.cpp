/* 
  Fichero: genera-unimodal.cpp
  Autores:  Joaquín García Venegas
            Joaquín Alejandro España Sánchez
            Pedro Bedmar López
            Alejandro Escalona García
  Fecha: 05/04/20
  Compilación: g++ genera-unimodal.cpp -o genera-unimodal
*/
#include <iostream>
#include <ctime>
#include <cstdlib>
#include <climits>
#include <cassert>
#include <chrono>   // high_resolution_clock

using namespace std;

// generador de ejemplos para el problema de la serie unimodal 
// de números. Se genera un índice aleatorio entre 1 y n-2, se 
// asigna el mayor entero (n-1) a ese índice, a los índices 
// anteriores a p se le asignan valores en orden creciente (0,1,...,p-1)
// y a los índices mayores que p se le asignan valores en orden 
// decreciente (n-2, n-1,...,p)

double uniforme() //Genera un número uniformemente distribuido en el
                  //intervalo [0,1) a partir de uno de los generadores
                  //disponibles en C.
{
  double u;
  u = (double)rand();
  u = u / (double)(RAND_MAX + 1.0);
  return u;
}

// Función realizada aplicando un algoritmo de fuerza bruta
int Unimodal(int T[], int n)
{
  int indice_p = -1;
  const int MIN_ELEMENTOS = 3;

  // El índice no puede ser ni la primera ni la última posición del vector, 
  // por lo que el número de elementos (n) deberá ser >= 3
  if(n >= MIN_ELEMENTOS){
    int i = 0;
    bool terminar=false;

    while(!terminar){
      if(T[i] > T[i+1]){
        indice_p = i;
        terminar=true;
      }
      i++;
    }
  }

  return indice_p;
}


int main(int argc, char *argv[])
{

  if (argc != 2)
  {
    cerr << "Formato " << argv[0] << " <num_elem>" << endl;
    return -1;
  }
  clock_t tantes;    // Valor del reloj antes de la ejecuci�n
  clock_t tdespues;  // Valor del reloj despu�s de la ejecuci�n
  

  int n = atoi(argv[1]);

  int *T = new int[n];
  assert(T);

  srand(time(0));
  double u = uniforme();
  int p = 1 + (int)((n - 2) * u);
  T[p] = n - 1;


  // Rellenar parte izquierda ascendentemente
  for (int i = 0; i < p; i++)
    T[i] = i;

  // Rellenar parte derecha descendentemente
  for (int i = p + 1; i < n; i++)
    T[i] = n - 1 - i + p;


  //auto inicio = std::chrono::high_resolution_clock::now();  // Guardar tiempo de inicio
  int indice_p = Unimodal(T, n);     
  //auto fin = std::chrono::high_resolution_clock::now();     // Guargar tiempo de fin

  // Calcular tiempo del algoritmo
  //std::chrono::duration<double> transcurrido = fin - inicio;

  // Impresión del vector
  for (int j = 0; j < n; j++)
    cout << T[j] << " ";
  
  //cout << n << "  " <<  transcurrido.count() << "\n";
  //Imprimir valor del indice p
  cout << "\nEl valor del indice p es: " << indice_p << endl;
}
