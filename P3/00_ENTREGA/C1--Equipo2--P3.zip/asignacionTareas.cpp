/* 
  Fichero: asignacionTareas.cpp
  Autores:  Joaquín García Venegas
            Joaquín Alejandro España Sánchez
            Pedro Bedmar López
            Alejandro Escalona García
  Fecha: 27/04/20
  Compilación: g++ asignacionTareas.cpp -o asignacionTareas
*/
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>   

using namespace std;

struct tarea{
    int indice_tarea;
    int beneficio;
    int instante_fin;
};

void LeerTareas(vector<tarea> &v, int n_tareas, istream& is){
    for(int i=0; i < n_tareas; i++){
        tarea t;
        
        t.indice_tarea = i;         // Asignar indice i a la tarea
        is >> t.beneficio;         // Leer beneficio de la tarea i
        is >> t.instante_fin;      // Leer el instante de finalización

        // Restamos uno para evitar tener que poner un índice menos
        // después para el vector
        t.instante_fin -=1;     

        // Añadir tarea i conjunto de tareas
        v.push_back(t);
    }
}


void MostrarTabla(vector<tarea> v){
    
    cout << "Las tareas introducidas con las siguientes: " << endl;
    // Índice de tarea
    cout << "I";
    for(int i=0; i < v.size(); i++){
        cout << "\t" << i+1;//Le sumamos 1 porque nosotros trabajamos empezando por el indice 0
    }

    // Beneficio
    cout << endl << "Gi";
    for(int i=0; i < v.size(); i++){
        cout << "\t" << v[i].beneficio;
    }

    // Instante de finalización
    cout << endl << "Di";
    for(int i=0; i < v.size(); i++){
        cout << "\t" << v[i].instante_fin+1; // Le sumamos 1 porque nosotros trabajamos
                                             // empezando por el indice 0
    }
    cout << endl;
}

int calculaBeneficio(const vector<tarea>& tareas, const vector<int>& secuencia_indices)
{
    int beneficio = 0;
    for(int i=0; i< secuencia_indices.size(); i++){
        beneficio += tareas[secuencia_indices[i]].beneficio;
    }

    return beneficio;
}


bool ordenaDi(const tarea& t1, const tarea& t2)
{
    return t1.instante_fin > t2.instante_fin;
}


bool ordenaBeneficio(const tarea& t1, const tarea& t2)
{
    // Cuando tienen el mismo beneficio, se prioriza
    // al que tiene instante de finalización menor
    if(t1.beneficio == t2.beneficio){
        return t1.instante_fin <= t2.instante_fin; 
    }
    return(t1.beneficio >= t2.beneficio);
}

//Funcion para obtener el di (instante maximo) maximo de todas las tareas
int instante_max_vector(vector<tarea> tareas){
    vector<tarea> tareas_ordenadas_di = tareas;
    
    //Ordenamos de mayor a menor di
    sort(tareas_ordenadas_di.begin(), tareas_ordenadas_di.end(), ordenaDi);
    
    //Devolvemos el di de la primera
    return tareas_ordenadas_di[0].instante_fin;
}


// Función que selecciona de las tareas que quedan 
// cual es la mejor
//int seleccion(const vector<tarea>& tareas, const vector<int>& secuencia_indices)


vector<int> planTareas(vector<tarea> lista_tareas, int max_tareas)
{
    vector<int> secuencia(max_tareas,-1);
    vector<tarea> lista_ordenada = lista_tareas;
    int tareas_introducidas = 0;
    
    // Ordenamos las tareas en orden decreciente de beneficio
    sort(lista_ordenada.begin(), lista_ordenada.end(), ordenaBeneficio);
    
    // Realizamos tantos intentos como max_tareas tengamos
    int i=0;
    //Mientras no se hayan introducido el maximo de tareas y no se hayan comprobado todas las tareas ya
    while(tareas_introducidas != max_tareas && i!=lista_tareas.size()){

        // Metemos la tarea i (del vector ordenado por beneficio) en la posicion del vector secuencia 
        //indicada por su instante_fin, de esta forma, los indices del vector secuencia serian el di maximo
        //que se puede introducir, por ejemplo, una tarea con di = 2, podra ir en la posicion 0,1 o 2, nunca 
        //en las siguientes, ya que no produciria beneficio

        // En el caso de que la posición i ya hubiese sido ocupada por otra 
        // tarea, esta se colocará en donde haya un hueco anterior a esa posicion

        int pos_insertar = lista_ordenada[i].instante_fin;
        if(secuencia[pos_insertar] != -1){ //Si esta ocupada, buscamos un hueco libre anterior
            int pos_anterior = pos_insertar; //La inicializamos a la posicion donde se deberia haber insertado
            if(pos_anterior != 0){ //Si es 0, no podremos acceder a una posicion anterior, por lo que no se introduce la tarea
                pos_anterior--; //Nos movemos a la posicion anterior
                while(secuencia[pos_anterior] != -1 && //Mientras siga sin encontrar hueco
                     (pos_anterior) >= 0) // y queden posiciones anteriores por recorrer 
                                        //(incluimos el 0, para que si la pos 0 esta ocupada,
                                         //la posicion sea la -1 y no se introduzca luego)
                {
                    pos_anterior--;
                }
                if(pos_anterior >= 0)  //Comprobamos que esta dentro del vector, para el caso
                {                      // en el que sea la posicion -1, como hemos comentado arriba
                    secuencia[pos_anterior] = i;
                    tareas_introducidas++;
                }
            }      
        }
        else{ //Si esta libre, la insertamos
            secuencia[pos_insertar] = i;
            tareas_introducidas++;
        }

        i++; //Avanzamos a la siguiente tarea
    }

    //Como el vector secuencia contiene los indices de las tareas ordenadas, 
    //los cambiamos por el indice de tarea que tenia al inicio, cuando se introdujeron
    for(int j=0; j<max_tareas; j++){

        //Obtenemos el indice de la tarea en el vector de secuencia
        int indice_tarea_insertada = secuencia[j];

        // Camibamos el indice de la tarea ordenada por el indice inicial
        if(indice_tarea_insertada != -1) //Si el indice es -1, es que no se corresponde con ninguna tarea
            secuencia[j] = lista_ordenada[indice_tarea_insertada].indice_tarea;
    }

    return(secuencia);
}

int main(int argc, char * argv[])
{
    // Comprobar número de argumentos
    if(argc != 2){
        cout << "Número incorrecto de argumentos." << endl;
        cout << "Ejemplo de uso: ./asignacionTareas <fichero>." << endl;
        return 0;
    }

    // Comprobar si se puede abrir el fichero
    ifstream fichero(argv[1]);
    if(!fichero){
        cout << "No puedo abrir " << argv[1] << endl;
        return 0;
    }

    int n;
    vector<tarea> v_tareas;

    fichero >> n;   // Lectura del número de tareas (n)

    LeerTareas(v_tareas, n, fichero);
    MostrarTabla(v_tareas);

    // Calcular el número máximo de tareas que podrán haber en la planificación
    int max_tareas = min(n, instante_max_vector(v_tareas)+1);
    

    // Algoritmo voraz
    vector<int> solucion = planTareas(v_tareas, max_tareas);

    cout << "\nLa secuencia de tareas es: ";
    for(int i=0; i<solucion.size(); i++){
        if(solucion[i] != -1)             //Si vale -1 es que no hay ninguna tarea en esa posicion
            cout << solucion[i]+1 << " "; //Le sumamos 1 porque nosotros trabajamos empezando por el indice 0
    }
    
    cout << "\nCon un beneficio total de: " << calculaBeneficio(v_tareas, solucion) << endl;
    cout << endl;    

}
